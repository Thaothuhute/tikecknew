//
//  maybay.swift
//  planeticket2
//
//  Created by Thu Thão on 25/05/2023.
//

import Foundation
struct maybay{
    let id: String
    let dangbay:Bool
    let idmaybay:Int
    let tenmaybay : String
    
    init(id: String, dangbay: Bool, idmaybay: Int, tenmaybay: String) {
        self.id = id
        self.dangbay = dangbay
        self.idmaybay = idmaybay
        self.tenmaybay = tenmaybay
    }
    
}
