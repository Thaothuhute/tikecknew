//
//  chitietve.swift
//  planeticket2
//
//  Created by Thu Thão on 26/05/2023.
//

import Foundation
struct chitietgia{
    var giave:Float
    var iddiadiemden:Int
    var iddiadiemdi:Int
    var idloaive:Int
    init(giave: Float, iddiadiemden: Int, iddiadiemdi: Int, idloaive: Int) {
        self.giave = giave
        self.iddiadiemden = iddiadiemden
        self.iddiadiemdi = iddiadiemdi
        self.idloaive = idloaive
    }
}
