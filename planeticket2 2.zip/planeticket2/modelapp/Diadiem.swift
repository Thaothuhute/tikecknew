//
//  Diadiem.swift
//  planeticket2
//
//  Created by Thu Thão on 22/05/2023.
//

import Foundation
public struct diaDiem {
    
    public let tendiadiem: String
    public let iddiadiem: Int
    
    public init(tendiadiem :String,iddiadiem:Int){
        self.tendiadiem = tendiadiem
        self.iddiadiem = iddiadiem
    }
    
}
