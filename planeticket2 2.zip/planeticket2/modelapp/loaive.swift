//
//  loaive.swift
//  planeticket2
//
//  Created by Thu Thão on 26/05/2023.
//

import Foundation
struct loaive{
    var tenloai:String
    init(tenloai: String) {
        self.tenloai = tenloai
    }
}
