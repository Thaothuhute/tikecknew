//
//  test.swift
//  planeticket2
//
//  Created by DoanThinh on 5/14/23.
//

import SwiftUI

struct test: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct test_Previews: PreviewProvider {
    static var previews: some View {
        test()
    }
}
